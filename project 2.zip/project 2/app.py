import pygame
import random

pygame.init()

# Constants
SCREEN_WIDTH, SCREEN_HEIGHT = 640, 480
GRID_SIZE = 20
GRID_WIDTH, GRID_HEIGHT = SCREEN_WIDTH // GRID_SIZE, SCREEN_HEIGHT // GRID_SIZE
SNAKE_BLOCK_SIZE = 20
SNAKE_SPEED = 15
FONT_STYLE = 'comicsansms'
FONT_SIZE = 25

# Colors
WHITE = (255, 255, 255)
RED = (213, 50, 80)
GREEN = (0, 255, 0)
BLUE = (50, 153, 213)

# Create the game window
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('Snake Game')

# Snake function
def draw_snake(snake_body):
    for block in snake_body:
        pygame.draw.rect(screen, GREEN, [block[0], block[1], SNAKE_BLOCK_SIZE, SNAKE_BLOCK_SIZE])

# Main game loop
def game_loop():
    game_over = False
    game_close = False

    # Initial snake position and movement
    snake_x, snake_y = SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2
    snake_x_change, snake_y_change = 0, 0
    snake_body = []
    snake_length = 1

    # Initial food position
    food_x, food_y = round(random.randrange(0, SCREEN_WIDTH - SNAKE_BLOCK_SIZE) / 20.0) * 20, round(random.randrange(0, SCREEN_HEIGHT - SNAKE_BLOCK_SIZE) / 20.0) * 20

    clock = pygame.time.Clock()

    while not game_over:

        while game_close:
            screen.fill(WHITE)
            font_style = pygame.font.SysFont(FONT_STYLE, FONT_SIZE)
            message = font_style.render("You Lost! Press Q-Quit or C-Play Again", True, BLUE)
            screen.blit(message, [SCREEN_WIDTH / 6, SCREEN_HEIGHT / 3])
            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        game_over = True
                        game_close = False
                    if event.key == pygame.K_c:
                        game_loop()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    snake_x_change = -SNAKE_BLOCK_SIZE
                    snake_y_change = 0
                elif event.key == pygame.K_RIGHT:
                    snake_x_change = SNAKE_BLOCK_SIZE
                    snake_y_change = 0
                elif event.key == pygame.K_UP:
                    snake_y_change = -SNAKE_BLOCK_SIZE
                    snake_x_change = 0
                elif event.key == pygame.K_DOWN:
                    snake_y_change = SNAKE_BLOCK_SIZE
                    snake_x_change = 0

        if snake_x >= SCREEN_WIDTH or snake_x < 0 or snake_y >= SCREEN_HEIGHT or snake_y < 0:
            game_close = True

        snake_x += snake_x_change
        snake_y += snake_y_change
        screen.fill(WHITE)
        pygame.draw.rect(screen, BLUE, [food_x, food_y, SNAKE_BLOCK_SIZE, SNAKE_BLOCK_SIZE])
        snake_head = []
        snake_head.append(snake_x)
        snake_head.append(snake_y)
        snake_body.append(snake_head)
        if len(snake_body) > snake_length:
            del snake_body[0]

        for block in snake_body[:-1]:
            if block == snake_head:
                game_close = True

        draw_snake(snake_body)

        pygame.display.update()

        if snake_x == food_x and snake_y == food_y:
            food_x, food_y = round(random.randrange(0, SCREEN_WIDTH - SNAKE_BLOCK_SIZE) / 20.0) * 20, round(random.randrange(0, SCREEN_HEIGHT - SNAKE_BLOCK_SIZE) / 20.0) * 20
            snake_length += 1

        clock.tick(SNAKE_SPEED)

    pygame.quit()
    quit()

# Start the game loop
game_loop()
